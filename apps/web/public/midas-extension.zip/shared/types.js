const s={midasUrl:"https://midas.booute.duckdns.org",midasApiUrl:"https://midas.booute.duckdns.org"},t="pendingCapture";export{s as D,t as P};
