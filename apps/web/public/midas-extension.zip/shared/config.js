import{D as t}from"./types.js";async function r(){const o=await chrome.storage.sync.get("config");return{...t,...o.config??{}}}export{r as g};
