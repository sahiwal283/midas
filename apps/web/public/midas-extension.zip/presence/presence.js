try{document.documentElement.dataset.midasExtension=chrome.runtime.getManifest().version}catch{}
